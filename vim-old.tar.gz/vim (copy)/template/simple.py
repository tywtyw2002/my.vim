#!/usr/bin/env python
# -*- coding: UTF-8 -*-
# vim:set shiftwidth=4 tabstop=4 expandtab textwidth=79:
# work with python 2.7

def main():
    '''main: Main function

    Description goes here.
    '''
    print 'main'


if __name__ == '__main__':
    main()
